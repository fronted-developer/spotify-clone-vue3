import DefaultTheme from 'vitepress/theme'
import './styles.css'

export default {
  ...DefaultTheme,
}
