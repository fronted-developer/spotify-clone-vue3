export interface Data {
  [key: string]: unknown
}
